void main() {
  print('hello world');
  // Print function is used to print something on console.
}

/*
  Output:
  hello world
*/