void main() {
  int i;
  for (i = 0; i < 10; i++) {
    print("number ${i + 1}");
  }
}

/*
  Output:
  number 1
  number 2
  number 3
  number 4
  number 5
  number 6
  number 7
  number 8
  number 9
  number 10
*/